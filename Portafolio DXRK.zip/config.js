export const config = {
  primaryColor: '#8338EC',
  secondaryColor: '#6c757d',
  accentColor: '#ffc107'
};

